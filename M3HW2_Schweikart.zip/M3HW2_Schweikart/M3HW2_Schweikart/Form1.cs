﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/**
* 10/12/18
* CSC 253
* Brian Schweikart
* Use tokens and dlimiters to read a string and total the number
*/

namespace M3HW2_Schweikart
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void sumButton_Click(object sender, EventArgs e)
        {
            string num = numTextBox.Text.Trim(); //
            int sum = 0;
            char[] delimiter = {','}; // set token
            num = num.Trim(); // Trim the string
            string[] tokens = num.Split(delimiter); // Get tokens

            foreach(string number in tokens) // Check check if a number is used
            {
                if(IsNum(number))
                {
                    sum = sum + Convert.ToInt32(number); // might need to get out of the habbit of using this, I switch between both to much
                }
            }

            sumTextBox.Text = sum.ToString();  //display the sum
        }

        private bool IsNum(string number)
        {
            bool num = true;

            foreach(char ch in number)
            {
                if(!char.IsDigit(ch))
                {
                    num = false;
                    break;
                }
            }

            return num;
        }

        private void clearButton_Click(object sender, EventArgs e) // Clear the text boxes of information
        {
            numTextBox.Text = "";
            sumTextBox.Text = "";
        }

        private void exitButton_Click(object sender, EventArgs e) // close the form
        {
            this.Close(); 
        }
    }
}
