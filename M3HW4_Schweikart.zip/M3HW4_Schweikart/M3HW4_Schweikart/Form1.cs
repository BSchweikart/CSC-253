﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/**
* 10/20/18
* CSC 253
* Brian Schweikart
* Convert userinput into morse code.
* 
* keep getting error when you use a space of being outside of bounds
*/

namespace M3HW4_Schweikart
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private char[] input = 
            {'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z',
            '0','1','2','3','4','5','6','7','8','9',',','.',' '};
        private string[] code = { ".-", "-...", "-.-.", "-..", ".", "..-.", "--.", "....", "..", ".---", "-.-", ".-..",
            "--", "-.", "---", ".--.", "--.-", ".-.", "...", "-", "..-", "...-", ".--", "-..-", "--..", "-----", ".-----",
            "..---", "...--", "....-", ".....", "-....", "--...", "---..", "----.", "--..--", ".-.-.-", " "};
        private void convertButton_Click(object sender, EventArgs e)
        {
            
            string pText = inputTextBox.Text;
            string result = "";
            int count = 0;
            for (int i = 0; i < pText.Length; i++)
            {
                for(int j = 0; j < input.Length; j++)
                {
                    char letter = char.ToUpper(pText[i]);

                    if (letter == input[j])
                    {
                        result = result + code[j]; // space keeps giving outside array
                        count++;
                    }
                }
            }
            if (count == pText.Length) // display result
            {
                outputTextBox.Text = result;                
            }
            
        }

        private void clearButton_Click(object sender, EventArgs e) // Clear the fields
        {
            inputTextBox.Clear();
            outputTextBox.Clear();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        } // Close the form
    }
}
