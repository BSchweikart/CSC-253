﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employee_and_ProductionWorker_Classes
{
    class Employee
    {
        int _employeeNumber;
        string _employeeName;

        public int employeeNumber { get { return _employeeNumber; } set { _employeeNumber = value; } }
        public string employeeName { get { return _employeeName; } set { _employeeName = value; } }

        
    }
}
