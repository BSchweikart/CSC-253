﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/**
 * 08/30/2018
 * CSC-253
 * Brian Schweikart
 * Book Club Points
 */

namespace Book_Club_Points
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            // set varables
            int points = 0; //set points at zero
            int quantity = 0; // set quantity of books to zero

            // Tryparse will not convert this takes the sting and converts it to int(32) is the base.
            // was trying to put this into a while statement but would only get a blank screen
            // going to play around with the above and lower and see if I can get a switch statment to work also
            quantity = Convert.ToInt32(quantityTextBox.Text);

            // if the quantity of the input is 0 then display total points
            if(quantity == 0)
            {
                points = 0;
            }

            // if the quantity of the input is 1 then display total points
            if (quantity == 1)
            {
                points = 5;
            }

            // if the quantity of the input is 2 then display total points
            if (quantity == 2)
            {
                points = 15;
            }

            // if the quantity of the input is 3 then display total points
            if (quantity == 3)
            {
                points = 30;
            }

            // if the quantity of the input is 4 or more then display total points
            if (quantity >= 4)
            {
                points = 60;

                // Out put total points to the lable per each quantity of books.
                pointsLabel.Text = points.ToString();
            }


        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Close this form
            this.Close();
        }
    }
}
