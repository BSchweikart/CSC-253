﻿namespace Kinetic_Energy
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.outputLabel = new System.Windows.Forms.Label();
            this.calculateButton = new System.Windows.Forms.Button();
            this.massLabel = new System.Windows.Forms.Label();
            this.velocityLabel = new System.Windows.Forms.Label();
            this.kineticLabel = new System.Windows.Forms.Label();
            this.massTextBox = new System.Windows.Forms.TextBox();
            this.VelocityTextBox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // outputLabel
            // 
            this.outputLabel.AutoSize = true;
            this.outputLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.outputLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.outputLabel.Location = new System.Drawing.Point(212, 213);
            this.outputLabel.Name = "outputLabel";
            this.outputLabel.Size = new System.Drawing.Size(2, 22);
            this.outputLabel.TabIndex = 0;
            // 
            // calculateButton
            // 
            this.calculateButton.Location = new System.Drawing.Point(95, 160);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(192, 30);
            this.calculateButton.TabIndex = 1;
            this.calculateButton.Text = "Calculate Kinetic Energy";
            this.calculateButton.UseVisualStyleBackColor = true;
            this.calculateButton.Click += new System.EventHandler(this.Calculate_Click);
            // 
            // massLabel
            // 
            this.massLabel.AutoSize = true;
            this.massLabel.Location = new System.Drawing.Point(38, 43);
            this.massLabel.Name = "massLabel";
            this.massLabel.Size = new System.Drawing.Size(103, 17);
            this.massLabel.TabIndex = 2;
            this.massLabel.Text = "Enter the Mass";
            // 
            // velocityLabel
            // 
            this.velocityLabel.AutoSize = true;
            this.velocityLabel.Location = new System.Drawing.Point(38, 107);
            this.velocityLabel.Name = "velocityLabel";
            this.velocityLabel.Size = new System.Drawing.Size(119, 17);
            this.velocityLabel.TabIndex = 3;
            this.velocityLabel.Text = "Enter the Velocity";
            // 
            // kineticLabel
            // 
            this.kineticLabel.AutoSize = true;
            this.kineticLabel.Location = new System.Drawing.Point(38, 213);
            this.kineticLabel.Name = "kineticLabel";
            this.kineticLabel.Size = new System.Drawing.Size(135, 17);
            this.kineticLabel.TabIndex = 4;
            this.kineticLabel.Text = "Total Kinetic Energy";
            // 
            // massTextBox
            // 
            this.massTextBox.Location = new System.Drawing.Point(187, 43);
            this.massTextBox.Name = "massTextBox";
            this.massTextBox.Size = new System.Drawing.Size(100, 22);
            this.massTextBox.TabIndex = 6;
            // 
            // VelocityTextBox
            // 
            this.VelocityTextBox.Location = new System.Drawing.Point(187, 107);
            this.VelocityTextBox.Name = "VelocityTextBox";
            this.VelocityTextBox.Size = new System.Drawing.Size(100, 22);
            this.VelocityTextBox.TabIndex = 7;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(436, 311);
            this.Controls.Add(this.VelocityTextBox);
            this.Controls.Add(this.massTextBox);
            this.Controls.Add(this.kineticLabel);
            this.Controls.Add(this.velocityLabel);
            this.Controls.Add(this.massLabel);
            this.Controls.Add(this.calculateButton);
            this.Controls.Add(this.outputLabel);
            this.Name = "Form1";
            this.Text = "Kinetic Energy";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label outputLabel;
        private System.Windows.Forms.Button calculateButton;
        private System.Windows.Forms.Label massLabel;
        private System.Windows.Forms.Label velocityLabel;
        private System.Windows.Forms.Label kineticLabel;
        private System.Windows.Forms.TextBox massTextBox;
        private System.Windows.Forms.TextBox VelocityTextBox;
    }
}

