﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/**
* 10/18/18
* CSC 253
* Brian Schweikart
* Sentence Capitalizer
*/

namespace M3HW3_Schweikart
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void conButton_Click(object sender, EventArgs e) // was over thinking it. using a bool made it better to understand
        {
            bool Upper = true;
            foreach (char letter in inputTextBox.Text)  // 
            {
                if (Upper == true)
                {
                    if (letter == ' ')
                    {
                        outputTextBox.Text += letter; //forot the + sign and would throw error for convert
                        continue;
                    }
                    outputTextBox.Text += letter.ToString().ToUpper(); // for got the + sign and was only showing the end of the string
                    Upper = false;
                }
                else
                {
                    outputTextBox.Text += letter;
                }
                if (letter == '.') // if a . is in the string the next letter is true run if statement.
                    Upper = true;
            }           
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            inputTextBox.Clear();
            outputTextBox.Clear();
        } //Clear the text boxes

        private void exitButton_Click(object sender, EventArgs e) // Close the form
        {
            this.Close(); 
        }  
    }
}
