﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/**
 * 09/07/2018
 * CSC 253
 * Brian Schwiekart
 * Retail Item Class call on the RetailItem class then pass as an array
 */

namespace Retailltem_Class
{
    public partial class Form1 : Form
    {
       
        public Form1()
        {
            InitializeComponent();
        }

        private void displayButton_Click(object sender, EventArgs e)
        {
            // call the RetailItem class and set values in array
            // Set information to string.
            // This part would keep throwing errors after errors played around looked around found the mistake I was doing.
            RetailItem[] product = new RetailItem[3];
            product[0] = new RetailItem("Jacket", 12, 59.95);
            product[1] = new RetailItem("Jeans", 40, 34.95);
            product[2] = new RetailItem("Shirt", 20, 24.95);

            // For loop to follow until list complete
            for(int index = 0; index < product.Length; index ++)
            {
                // display to list box
                // I could not find out how to line everything up with the labels. 
                productListBox.Items.Add ("Item " + (index + 1) + "---------- " + product[index].Description + "---------- " + 
                    product[index].UnitsOnHand + "---------- " + product[index].Price.ToString("c"));
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // close the form
            this.Close();
        }
    }
}
