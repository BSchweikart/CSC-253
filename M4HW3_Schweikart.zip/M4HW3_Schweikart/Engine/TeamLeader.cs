﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Engine
{
    public class TeamLeader : Employee
    {
        int _hReqTrain;
        decimal _monBonus;

        public int HReqTrain { get {return _hReqTrain; } set { _hReqTrain = value; } }
        public decimal MonBonus { get {return _monBonus; } set { _monBonus = value; } }


    }
}
