﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Retailltem_Class
{
    class RetailItem
    {
        public string Description;
        public int UnitsOnHand;
        public double Price;

        public RetailItem(string descrip, int units, double cost)
        {
            Description = descrip;
            UnitsOnHand = units;
            Price = cost;
        }

        
    }
    
}
