﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Engine
{
    public class ProductionWorker : Employee
    {
        int _shiftNumber;
        decimal _payRate;

        public int ShiftNumber { get{ return _shiftNumber; } set { _shiftNumber = value; } }
        public decimal PayRate {get { return _payRate; } set { _payRate = value; } }
    }
}
