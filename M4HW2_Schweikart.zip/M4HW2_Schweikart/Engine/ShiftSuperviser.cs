﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Engine
{
    public class ShiftSuperviser : Employee
    {
        decimal _salaryAnual;
        decimal _bonusAnual;

        public decimal SalaryAnual { get {return _salaryAnual; } set { _salaryAnual = value; } }
        public decimal BonusAnual { get {return _bonusAnual; } set { _bonusAnual = value; } }
    }
}
