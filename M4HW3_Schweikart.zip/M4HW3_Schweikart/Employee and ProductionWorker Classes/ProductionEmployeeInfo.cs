﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Engine;
using M4HW2_Schweikart;
using M4HW3_Schweikart;

/**
* 11/1/18
* CSC 253
* Brian Schweikart
* Inheritance class
*/

//Going to see if I can also combine all the HW into one.

namespace Employee_and_ProductionWorker_Classes
{
    public partial class ProductionEmployeeInfo : Form
    {
        public ProductionEmployeeInfo()
        {
            InitializeComponent();
        }

        private void ProductionWorkerInfo(ProductionWorker objPw)
        {
            int empNO;
            int shiftNO;
            decimal payRate;

            if (empNameTextBox.Text != "")
            {
                objPw.employeeName = empNameTextBox.Text;
            }
            else
            {
                MessageBox.Show("Enter an Employee Name");
            }

            if (int.TryParse(empNumTextBox.Text, out empNO))
            {
                objPw.employeeNumber = empNO;
            }
            else
            {
                MessageBox.Show("Enter an Employee Number");
            }

            if(int.TryParse(numShiftTextBox.Text, out shiftNO))
            {
                objPw.ShiftNumber = shiftNO;
            }
            else
            {
                MessageBox.Show("Enter an Employee Shift Number");
            }

            if (decimal.TryParse(payRateTextBox.Text, out payRate))
            {
                objPw.PayRate = payRate;
            }
            else
            {
                MessageBox.Show("Enter an Employee Rate of Pay");
            }

            
        }

        private void displayButton_Click(object sender, EventArgs e)
        {
            ProductionWorker objPw = new ProductionWorker();
            ProductionWorkerInfo(objPw);
            
                empNameLabel.Text = objPw.employeeName;
                empNumLabel.Text = objPw.employeeNumber.ToString();
                numShiftLabel.Text = objPw.ShiftNumber.ToString();
                payRateLabel.Text = objPw.PayRate.ToString("c");
            
        }

       
        private void clearButton_Click(object sender, EventArgs e) // Clear the form
        {
            empNameTextBox.Text = "";
            empNumTextBox.Text = "";
            numShiftTextBox.Text = "";
            payRateTextBox.Text = "";
            empNumLabel.Text = "";
            empNameLabel.Text = "";
            numShiftLabel.Text = "";
            payRateLabel.Text = "";

        }

        private void exitButton_Click(object sender, EventArgs e) // Close the program
        {
            this.Close();
        }

        private void supervisorButton_Click(object sender, EventArgs e)
        {
            ShiftSupervisorInfo shiftSuperviserInfo = new ShiftSupervisorInfo();
            shiftSuperviserInfo.Show();
            
        }

        private void teamLeadButton_Click(object sender, EventArgs e)
        {
            TeamLeaderInfo teamLeaderInfo = new TeamLeaderInfo();
            teamLeaderInfo.Show();
        }
    }
}