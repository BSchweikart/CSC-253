﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/**
* 08/2920189
* CSC 253
* Brian Schweikart
* Double pay each day off the last day.
*/
namespace Pennies_for_Pay
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            // set variables
            decimal income = 0.01m;
            int days = 0;
            int count = 1; // set counter to 1

            // Check for user input.
            if (int.TryParse(dayTextBox.Text, out days))
            {
                while (count <= days)
                {
                    payListBox.Items.Add("You pay for day " + count + (" is ") + income.ToString("c"));

                    // Calculate the pay increase
                    income = income * 2;

                    // set count
                    count++;
                }

            }
        }

        private void exitButton_Click_1(object sender, EventArgs e)
        {
            // close the form
            this.Close();
        }
    }
}