﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/**
* 10/11/18
* CSC 253
* Brian Schweikart
* Word Counter
* This is count the amount of words the user types in and then display the count
*/

namespace Word_Counter
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void countButton_Click(object sender, EventArgs e)
        {
            string str = wordTextBox.Text;

            if(str.Trim() == "")
            {
                MessageBox.Show("Please enter a word");
                return;
            }
            // Calling the method
            int wordCount = wordsCount (str);

            MessageBox.Show("Number of words is: " + wordCount.ToString());
        }

        // Meathod to call 
        private int wordsCount(string str)
        {
            int wordsCount = 0;

            string[] strWords = str.Split(null);
            wordsCount = strWords.Length;
            return wordsCount;
        }

        // Clear the text box
        private void clearButton_Click(object sender, EventArgs e)
        {
            wordTextBox.Text = "";
        }

        // Close the form
        private void exitEutton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
