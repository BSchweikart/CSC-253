﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/**
* 11/25/18
* CSC 253
* Brian Schweikart
* Set up a database for employee information
*  M5HW2 was just added in so that another base form didn't need to be created.
*/

namespace M5HW1_Schweikart
{
    public partial class personnelDatabase : Form
    {
        public personnelDatabase()
        {
            InitializeComponent();
        }

        private void employeeBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.employeeBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.employeeDataSet);

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'employeeDataSet.Employee' table. You can move, or remove it, as needed.
            this.employeeTableAdapter.Fill(this.employeeDataSet.Employee);

        }

        private void acendingButton_Click(object sender, EventArgs e)
        {
            // Sort by acending
            this.employeeTableAdapter.Ascending(this.employeeDataSet.Employee);
        }

        private void descendingButton_Click(object sender, EventArgs e)
        {
            // Sort by descending
            this.employeeTableAdapter.Descending(this.employeeDataSet.Employee);
        }

        private void searchButton_Click(object sender, EventArgs e)
        {
            // seach the data base for the information entered
            this.employeeTableAdapter.Search(this.employeeDataSet.Employee, searchTextBox.Text);
        }
    }
}
