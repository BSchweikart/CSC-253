﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/**
* 09/06/2018
* CSC 253
* Brian Schweikart
* User inputs mass and velocity to view total Kinetic Energy
*/

namespace Kinetic_Energy
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Calculate_Click(object sender, EventArgs e)
        {
             // Set the m and v as a double
            double m;
            double v;

            // Get user input from text boxes
            if (double.TryParse(massTextBox.Text, out m) && double.TryParse(VelocityTextBox.Text, out v))
            {
                // Call KineticEnergy and input user data in
                double ke = KineticEnergy(m, v);

                // out put total
                outputLabel.Text = ke.ToString("n");
            }
            // display error message if numbers are not entered
            else
                MessageBox.Show("Please enter a valid numbers");
        }
        private double KineticEnergy(double m, double v)
        {
            // had to look this up didn't know/forgot about Math and how to write it.
            // 0.5 * m(input) * (Math.Pow creates an exponent) for v(input) to 2
            double ke = 0.5 * m * Math.Pow(v, 2);
            //Return the value of above
            return ke;
        }
    }
}
