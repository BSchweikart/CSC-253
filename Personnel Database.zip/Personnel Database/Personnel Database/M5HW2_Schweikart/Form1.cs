﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using M5HW2_Schweikart;

namespace M5HW2_Schweikart
{
    public partial class hourlyPaySorter : Form
    {
        public hourlyPaySorter()
        {
            InitializeComponent();
        }
    }
}
