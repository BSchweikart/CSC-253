﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Engine;
/**
* 11/1/18
* CSC 253
* Brian Schweikart
* Inheritance class
* Useing a class Libary so that I don't have to keep making the employee class everytime
* Then making a project for each homework.
* I could have made all the forms in one solution
* The naming was not changing but when I did I would get errors. Seems to be something with the projects not changing the name fully.
*/

namespace M4HW2_Schweikart
{
    public partial class ShiftSupervisorInfo : Form
    {
        public ShiftSupervisorInfo()
        {
            InitializeComponent();
        }

        private void ShiftSupervisorInfomation(ShiftSuperviser objSs)
        {
            int empNO;
            decimal anualSal;
            decimal anualBonus;

            if (empNameTextBox.Text != "")
            {
                objSs.employeeName = empNameTextBox.Text;
            }
            else
            {
                MessageBox.Show("Enter an Employee Name");
            }

            if (int.TryParse(empNumTextBox.Text, out empNO))
            {
                objSs.employeeNumber = empNO;
            }
            else
            {
                MessageBox.Show("Enter an Employee Number");
            }

            if (decimal.TryParse(annualSalTextBox.Text, out anualSal))
            {
                objSs.SalaryAnual = anualSal;
            }
            else
            {
                MessageBox.Show("Enter the Anual Salary");
            }

            if (decimal.TryParse(AnnualBounsTextBox.Text, out anualBonus))
            {
                objSs.BonusAnual = anualBonus;
            }
            else
            {
                MessageBox.Show("Enter the Anual Bonus");
            }


        }

        private void displayButton_Click(object sender, EventArgs e)
        {
            ShiftSuperviser objSs = new ShiftSuperviser();
            ShiftSupervisorInfomation(objSs);

            empNameLabel.Text = objSs.employeeName;
            empNumLabel.Text = objSs.employeeNumber.ToString();
            AnnualSalLabel.Text = objSs.SalaryAnual.ToString("c");
            annualBounsLabel.Text = objSs.BonusAnual.ToString("c");
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            empNameTextBox.Text = "";
            empNumTextBox.Text = "";
            AnnualBounsTextBox.Text = "";
            annualSalTextBox.Text = "";
            empNameLabel.Text = "";
            empNumLabel.Text = "";
            AnnualSalLabel.Text = "";
            annualBounsLabel.Text = "";
        }

        private void exitButton_Click(object sender, EventArgs e) // close this form
        {
            this.Close();
        }
    }
}
