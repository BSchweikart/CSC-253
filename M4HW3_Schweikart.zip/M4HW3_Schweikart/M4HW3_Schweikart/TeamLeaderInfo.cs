﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Engine;

/**
* 11/5/18
* CSC 253
* Brian Schweikart
* Inheritance class
*/

namespace M4HW3_Schweikart
{
    public partial class TeamLeaderInfo : Form
    {
        public TeamLeaderInfo()
        {
            InitializeComponent();
        }

        private void TeamLeaderInformation( TeamLeader objTl)
        {
            int empNO;
            int reqHTran;
            decimal monthBonus;

            if (empNameTextBox.Text != "")
            {
                objTl.employeeName = empNameTextBox.Text;
            }
            else
            {
                MessageBox.Show("Enter an Employee Name");
            }

            if (int.TryParse(empNumTextBox.Text, out empNO))
            {
                objTl.employeeNumber = empNO;
            }
            else
            {
                MessageBox.Show("Enter an Employee Number");
            }

            if (int.TryParse(tranHReqTextBox.Text, out reqHTran))
            {
                objTl.HReqTrain = reqHTran;
            }
            else
            {
                MessageBox.Show("Enter the Anual Salary");
            }

            if (decimal.TryParse(monthBounsTextBox.Text, out monthBonus))
            {
                objTl.MonBonus = monthBonus;
            }
            else
            {
                MessageBox.Show("Enter the Anual Bonus");
            }
        }

        private void displayButton_Click(object sender, EventArgs e)
        {   TeamLeader objTl = new TeamLeader();
            TeamLeaderInformation(objTl);

            empNameLabel.Text = objTl.employeeName;
            empNumLabel.Text = objTl.employeeNumber.ToString();
            tranHReqLabel.Text = objTl.HReqTrain.ToString();
            monthBounsLabel.Text = objTl.MonBonus.ToString("c");
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            empNameTextBox.Text = "";
            empNameLabel.Text = "";
            empNumTextBox.Text = "";
            empNumLabel.Text = "";
            tranHReqTextBox.Text = "";
            tranHReqLabel.Text = "";
            monthBounsTextBox.Text = "";
            monthBounsLabel.Text = "";
        }

        private void exitButton_Click(object sender, EventArgs e) // close this form
        {
            this.Close(); 
        }
    }
}
